# Payment gateway bKash

payment gateway bKash for PHPNuxBill

## installation

Copy **bkash.php** to folder **system/paymentgateway/**

Copy **ui/bkash.tpl** to folder **system/paymentgateway/ui/**


## Author

 - [Ibnu Maksum aka ibnux](https://github.com/ibnux)

## Donations

### International

 - [Github Sponsor](https://github.com/sponsors/ibnux)
 - [Paypal](https://paypal.me/ibnux)

### Indonesia
 - [Trakteer iBNuX](https://trakteer.id/ibnux)